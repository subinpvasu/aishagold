<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. 
 * A mangosoft.in production.
 */

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Aisha Gold</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/style.css">

</head>
<body>

	<div class="container-fluid">
            
            <div class="row">
                <div class="col-md-12 header-top">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4" style="padding-top: 2px;"><i class="fa fa-envelope-o" aria-hidden="true"></i>
 <span>aishagold916@gmail.com</span>
</div>
                            <div class="col-md-4"></div>
                            <div class="col-md-4 to-right"  style="padding-top: 2px;"><i class="fa fa-phone" aria-hidden="true"></i>
                                <span>0497-2786230</span></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 header-middle">
                    <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <img src="images/logo.png" >
                        </div>
                        <div class="col-md-4"></div>
                        <div class="col-md-2 left-partition">
                            <div style="height:10px;"></div>
                            <img src="images/helpdesk.png">
                        </div>
                        <div class="col-md-2 left-partition">
                            <div style="height:10px;"></div>
                            <img src="images/goldrate.png">
                        </div>
                    </div>
                        </div>
                </div>
                <div class="col-md-12 header-menu">
                    <div class="container">
                    <div id="buttons">
    <ul>
        <li><a href="#">About Us</a></li>
        <li><a href="#">Diamond</a></li>
        <li><a href="#">Gold</a></li>
        <li><a href="#">Silver</a></li>
        <li><a href="#">Watches</a></li>
        <li><a href="#">Promotions</a></li>
        <li><a href="#">Stores</a></li>
    </ul>
</div>
                    </div>
                </div>
            </div>
            