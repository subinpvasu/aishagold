<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */
?>
<div class="row" style="background-image: url(./images/promotion_bg.png);background-repeat: no-repeat;">
    <div class="col-md-12" style="height: 400px;">
        <div class="container text-center">
            
            <div class="col-md-12" style="height:150px;"></div>
                
                <div class="col-md-4">
                    <div style="width:98%;margin: 0px auto;">
                        <img src="./images/testimonial_1.jpg" style="width:98%;height:200px;">
                    </div>
                </div>
                 <div class="col-md-4">
                     <div style="width:98%;margin: 0px auto;">
                         <img src="./images/testimonial_1.jpg" style="width:98%;height:200px;">
                     </div>
                 </div>
                 <div class="col-md-4">
                     <div style="width:98%;margin: 0px auto;">
                         <img src="./images/promo-video.jpg" style="width:98%;height:200px;">
                     </div>
                 </div>
                  
            
            
            </div>
    </div>
</div>

