<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

?>
<div class="row">
    <div class="col-md-12" style="height:400px;">
        <div class="container text-center">
            
            
                
                <div class="col-md-4">
                    <div style="width:98%;margin: 0px auto;">
                        <img src="./images/diamond_jwl.png" style="width:98%;height:320px;">
                    </div>
                </div>
                 <div class="col-md-4">
                     <div style="width:98%;margin: 0px auto;">
                         <img src="./images/gold_jwl.png" style="width:98%;height:320px;">
                     </div>
                 </div>
                 <div class="col-md-4">
                     <div style="width:98%;margin: 0px auto;">
                         <img src="./images/silver_jwl.png" style="width:98%;height:320px;">
                     </div>
                 </div>
                  
            
            
            </div>
    </div>
</div>