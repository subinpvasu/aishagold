<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */
?>
<div class="row" style="background-image: url(./images/news_bg.jpg);background-repeat: no-repeat;">
    <div class="col-md-12" style="height:350px;"></div>
</div> 
