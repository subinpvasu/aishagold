<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

?>
<div class="row">
    <div class="col-md-12" style="background-color: #FBFBFD;height:120px;">
         <div id="buttons">
    <ul>
        <li><a href="#"><i class="fa fa-cogs fa-4x new-line ico-color" aria-hidden="true"></i>
Product Service</a></li>
        <li><a href="#"><i class="fa fa-file-text fa-4x new-line ico-color" aria-hidden="true"></i>
Detail Pricing</a></li>
        <li><a href="#"><i class="fa fa-file-image-o fa-4x new-line ico-color" aria-hidden="true"></i>

Certified Jewellery</a></li>
        <li><a href="#"><i class="fa fa-exchange fa-4x new-line ico-color" aria-hidden="true"></i>
Easy Exchange</a></li>
        <li><a href="#"><i class="fa fa-balance-scale fa-4x new-line ico-color" aria-hidden="true"></i>
Compare List</a></li>
    </ul>
</div>
    </div>
</div>