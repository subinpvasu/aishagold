<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

include_once './header.php';
include_once './includes/carousal.php';
include_once './includes/service_tab.php';
include_once './includes/jewellery_tab.php';
include_once './includes/promotion_tab.php';
include_once './includes/news_events_tab.php';
include_once './footer.php';