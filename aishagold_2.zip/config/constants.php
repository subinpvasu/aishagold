<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

class system_constants{
    public static $SERVER_NAME = "localhost";
    public static $USER_NAME = "root";
    public static $PASSWORD = "";
    public static $DB_NAME = "aisha_store";
    public static $MYSQL_CONNECTION_ERROR = "Failed to connect to MySQL: ";
}