<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */
?>


<div class="row" style="border-top:4px solid #EEAA2F;">
    <div class="col-md-12" style="height:20px;"></div>
    <div class="col-md-12" style="height:200px;">
         <div class="container">
             <div class="col-md-10">
                 <div class="col-md-3">
                     <a href="" class="foot-title">Corporate Info</a>
                     <div style="height: 15px; width: 40%; border-top: 3px solid #EEAA2F;"></div>
                     <a href="" class="foot-item-up">about us</a>
                     <a href="" class="foot-item-up">history</a>
                     <a href="" class="foot-item-up">news &amp; events</a>
                     <a href="" class="foot-item-up">awards</a>
                     <a href="" class="foot-item-up">career</a>
                     <a href="" class="foot-item-up">blog</a>
                     <a href="" class="foot-item-up">store locator</a>
                 </div>
                 <div class="col-md-3">
                     <a href="" class="foot-title">Let us help you</a>
                     <div style="height: 15px; width: 40%; border-top: 3px solid #EEAA2F;"></div>
                     <a href="" class="foot-item-up">faq's</a>
                     <a href="" class="foot-item-up">contact us</a>
                     <a href="" class="foot-item-up">ring size guide</a>
                     <a href="" class="foot-item-up">bangle size guide</a>
                     <a href="" class="foot-item-up">gift cards</a>
                     <a href="" class="foot-item-up">education</a>
                     <a href="" class="foot-item-up">sitemap</a>
                 </div>
                 <div class="col-md-3">
                     <a href="" class="foot-title">useful links</a>
                     <div style="height: 15px; width: 40%; border-top: 3px solid #EEAA2F;"></div>
                     <a href="" class="foot-item-up">make an appointment</a>
                     <a href="" class="foot-item-up">build your custom jewellery</a>
                     <a href="" class="foot-item-up">smart buy</a>
                     <a href="" class="foot-item-up">offers</a>
                     <a href="" class="foot-item-up">new arrivals</a>
                     <a href="" class="foot-item-up">exclusive collection</a>
                 </div>
                 <div class="col-md-3">
                     <a href="" class="foot-title">Customer service</a>
                     <div style="height: 15px; width: 40%; border-top: 3px solid #EEAA2F;"></div>
                     <div style="color:#929292">
                         Chakkarakkal<br/>
	   Towngate, Opp.Bus Stand,<br/>
	   Chakkarakkal, PO Mowanachery,<br/>
	   Kannur DT-670613<br/>
	   Phone:0497-2853916<br/>
	   Head Office:0497 2786230
                     </div>
                 </div>
             </div>
             <div class="col-md-2">
                 <a href="" class="foot-title">Contact us @</a>
                 <div style="height: 15px; width: 40%; border-top: 3px solid #EEAA2F;"></div>
                 <div style="color:#929292">
                 <i class="fa fa-facebook fa-4x" aria-hidden="true"></i>
                 <i class="fa fa-twitter fa-4x" aria-hidden="true"></i>
                 <i class="fa fa-youtube fa-4x" aria-hidden="true"></i>
                 </div>



             </div>
                 
         </div>
    </div>
    <div class="col-md-12" style="height:20px;text-align: center;">&copy; 2016 Aisha Gold. All Rights Reserved.</div>
</div>



</div>

</body>
</html>
