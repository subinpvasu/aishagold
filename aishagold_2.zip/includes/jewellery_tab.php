<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

?>
<div class="row vertical-gap">
    <div class="col-md-12">
        <div class="container text-center">
            
            
                
                <div class="col-md-4">
                    <div class="jewellery-back jewellery-dmnd">
                        <div class="col-md-12 jewellery-inner" style="">
                            <img src="./images/diam-pd.png">
                        </div>
                        <div class="col-md-12 jewellery-bottom"  style="">
                            <div class="col-md-6 text-left">
                            <h4>DIAMOND<div class="default-color">JEWELLERY</div></h4>
                            </div>
                            <div class="col-md-6 jewellery-bottom-box" >
                                <a href="products.php?class=diamond"><h6>VIEW COLLECTION <span class="glyphicon glyphicon-play"></span></h6></a>
                            </div>
                            
                        </div>
                    </div>
                </div>
                 <div class="col-md-4">
                     <div class="jewellery-back jewellery-gold">
                        <div class="col-md-12 jewellery-inner" style="">
                            <img src="./images/gold-pd.png">
                        </div>
                        <div class="col-md-12 jewellery-bottom"  style="">
                              <div class="col-md-6 text-left">
                                  <h4>GOLD<div class="default-color">JEWELLERY</div></h4>
                            </div>
                            <div class="col-md-6 jewellery-bottom-box" >
                                <a href="products.php?class=gold"><h6>VIEW COLLECTION <span class="glyphicon glyphicon-play"></span></h6></a>
                            </div>
                        </div>
                    </div>
                 </div>
                 <div class="col-md-4">
                    <div class="jewellery-back jewellery-slvr">
                        <div class="col-md-12 jewellery-inner" style="">
                            <img src="./images/slvr-pd.png">
                        </div>
                        <div class="col-md-12 jewellery-bottom"  style="">
                            <div class="col-md-6 text-left">
                            <h4>SILVER<div class="default-color">JEWELLERY</div></h4>
                            </div>
                            <div class="col-md-6 jewellery-bottom-box">
                                <a href="products.php?class=silver"><h6>VIEW COLLECTION <span class="glyphicon glyphicon-play"></span></h6></a>
                            </div>
                        </div>
                    </div>
                 </div>
                  
            
            
            </div>
    </div>
</div>