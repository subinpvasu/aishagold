<?php
include_once './config/config.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */
$products = new database_helper();
   $rows = $products->diamond_products($_REQUEST['item']);
$row = mysqli_fetch_object($rows);
?>

<div class="row">
    <div class="col-md-3">
        
        <div class="product-box">
            <img src="./includes/<?php echo urldecode($row->image); ?>" class="product-desc-item">
        </div>
        <div style="width:300px;height: 40px;">
            
        </div>
        
        
    </div>
    
    <div class="col-md-3">
        <table class="table no-border-table">
            <tr>
                <td colspan="2"><h3 class="default-color"><?php echo urldecode($row->name); ?></h3></td>
                
            </tr>
            
            <tr>
                <td colspan="2"><h4>SPECIFICATIONS</h4></td>
               
            </tr>
            
            <tr>
                <td>Gender</td>
                <td><?php echo ucfirst($row->gender); ?></td>
            </tr>
            
            <tr>
                <td>Collection</td>
                <td><?php echo $row->collection; ?></td>
            </tr>
            
            <tr>
                <td>Product</td>
                <td><?php echo $row->product_type; ?></td>
            </tr>
            
            <tr>
                <td>Product Code</td>
                <td><?php echo $row->product_code; ?></td>
            </tr>
            
            <tr>
                <td>Gold Karatage</td>
                <td><?php echo $row->karatage; ?></td>
            </tr>
            
            <tr>
                <td>Brand</td>
                <td><?php echo $row->brand; ?></td>
            </tr>
            
            <tr>
                <td>Making</td>
                <td><?php echo $row->making; ?></td>
            </tr>
            
            <tr>
                <td>Tax</td>
                <td><?php echo $row->tax; ?></td>
            </tr>
        </table>
    </div>
</div>