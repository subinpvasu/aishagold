<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

?>
<div class="row">
    <nav class="navbar navbar-default">
 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#Navbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      </div>
    <div class="collapse navbar-collapse" id="Navbar">
         <div id="buttons">
    <ul class="nav navbar-nav">
        <li><a href="#"><i class="fa fa-cogs fa-4x new-line ico-color" aria-hidden="true"></i>
Product Service</a></li>
        <li><a href="#"><i class="fa fa-file-text fa-4x new-line ico-color" aria-hidden="true"></i>
Detail Pricing</a></li>
        <li><a href="#"><i class="fa fa-file-image-o fa-4x new-line ico-color" aria-hidden="true"></i>

Certified Jewellery</a></li>
        <li><a href="#"><i class="fa fa-exchange fa-4x new-line ico-color" aria-hidden="true"></i>
Easy Exchange</a></li>
        <li><a href="#"><i class="fa fa-balance-scale fa-4x new-line ico-color" aria-hidden="true"></i>
Compare List</a></li>
    </ul>
</div>
    </div> 

</nav>
</div>