<?php
include_once './config/config.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */
$products = new database_helper();
   $rows = $products->watch_products();
?>
<div class="row">
    <div class="col-sm-3">
        <h3 class="default-color under-line">COLLECTIONS</h3>
        <ul class="product-menu">
            <li id="bangle"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Bangle</li>
            <li id="chain"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Chain</li>
            <li id="ring"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Ring</li>
        </ul>
    
    </div>
    <div class="col-sm-9" style="min-height: 620px;height:auto;margin: 20px 0px;">
        <div class="row">
              <?php
             while($row = $rows->fetch_object()){
            ?>
            
             <div class="col-md-3 text-center">
                 <img src="./includes/<?php echo urldecode($row->image); ?>" class="product-desc-item">
                <h4><?php echo urldecode($row->name); ?></h4>
                <div class="jewellery-bottom-box" >
                    <a href="product_description.php?item=<?php echo $row->id ?>"><h6>VIEW DETAILS <span class="glyphicon glyphicon-play"></span></h6></a>
                            </div>
            </div>
            <?php
             }
            ?>
<!--            <div class="col-md-3 text-center">
                <img src="./images/product.png">
                <h4>Product One</h4>
                <div class="jewellery-bottom-box" >
                                <h6>VIEW DETAILS <span class="glyphicon glyphicon-play"></span></h6>
                            </div>
            </div>
            <div class="col-md-3 text-center">
                <img src="./images/product.png">
                <h4>Product One</h4>
                <div class="jewellery-bottom-box" >
                                <h6>VIEW DETAILS <span class="glyphicon glyphicon-play"></span></h6>
                            </div>
            </div>
            <div class="col-md-3 text-center">
                <img src="./images/product.png">
                <h4>Product One</h4>
                <div class="jewellery-bottom-box" >
                                <h6>VIEW DETAILS <span class="glyphicon glyphicon-play"></span></h6>
                            </div>
            </div>
            <div class="col-md-3 text-center">
                <img src="./images/product.png">
                <h4>Product One</h4>
                <div class="jewellery-bottom-box" >
                                <h6>VIEW DETAILS <span class="glyphicon glyphicon-play"></span></h6>
                            </div>
            </div>
             <div class="col-md-3 text-center">
                <img src="./images/product.png">
                <h4>Product One</h4>
                <div class="jewellery-bottom-box" >
                                <h6>VIEW DETAILS <span class="glyphicon glyphicon-play"></span></h6>
                            </div>
            </div>-->
        </div>
    </div>
  </div>