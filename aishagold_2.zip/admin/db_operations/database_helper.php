<?php

include_once '../config/constants.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */

class database_helper{
     private function get_connection(){
        try{
            $connection = new mysqli(system_constants::$SERVER_NAME, system_constants::$USER_NAME, 
                system_constants::$PASSWORD, system_constants::$DB_NAME);
            return $connection;
        } catch (Exception $ex) {
            trigger_error(system_constants::$MYSQL_CONNECTION_ERROR.$ex->getMessage(),E_ERROR);
        }
        
    }
    

    private function close_connection($connection){
        try{
            mysqli_close($connection);
        } catch (Exception $ex) {

        }
    }
   
    public function product_insert($data,$up)
    {
        $connect = $this->get_connection();
        if($up<0){
        $query = "INSERT INTO product_store(name, gender,category, collection, product_type, product_code, karatage, brand, making, tax, image, added) VALUES ('".$data['name']."','".$data['gender']."','".$data['category']."','".$data['collection']."','".$data['product_type']."','".$data['product_code']."','".$data['karatage']."','".$data['brand']."','".$data['making']."','".$data['tax']."','".$data['image']."',NOW())"; 
          $connect->query($query);
       $key = mysqli_insert_id($connect);
        }
        else
        {
            $query = "UPDATE product_store SET name='".$data['name']."',gender='".$data['gender']."',category='".$data['category']."',collection='".$data['collection']."',product_type='".$data['product_type']."',product_code='".$data['product_code']."',karatage='".$data['karatage']."',brand='".$data['brand']."',making='".$data['making']."',tax='".$data['tax']."',image='".$data['image']."',updated=NOW() WHERE id=".$up;
              $connect->query($query);
       $key = 100;
        }
      // echo $query ;
      
      
        
        $this->close_connection($connect);
        return $key;
    }
    
      public function promotion_insert($data,$up)
    {
        $connect = $this->get_connection();
        if($up<0)
        {
        $query = "INSERT INTO promotions( name, image, added) VALUES ('".$data['name']."','".$data['image']."',NOW())"; 
        
      // echo $query ;
      
        $connect->query($query);
       $key = mysqli_insert_id($connect);
        }
        else
        {
            $query = "UPDATE promotions SET name='".$data['name']."', image='".$data['image']."', updated=NOW() WHERE id=".$up; 
        
      // echo $query ;
      
        $connect->query($query);
       $key = 100;
        }
        
        $this->close_connection($connect);
        return $key;
    }
      public function news_insert($data,$up)
    {
        $connect = $this->get_connection();
        if($up<0)
        {
        $query = "INSERT INTO news_events( name, image, added) VALUES ('".$data['name']."','".$data['image']."',NOW())"; 
        
      // echo $query ;
      
        $connect->query($query);
       $key = mysqli_insert_id($connect);
        }else
        {
             $query = "UPDATE news_events SET name='".$data['name']."', image='".$data['image']."', updated=NOW() WHERE id=".$up; 
        
      // echo $query ;
      
        $connect->query($query);
       $key = 100;
        }
        
        $this->close_connection($connect);
        return $key;
    }
      public function all_products($id=null)
    {
        $connect = $this->get_connection();
        if(is_null($id))
        {
        $query = "SELECT * FROM product_store"; 
        }
        else
        {
            $query = "SELECT * FROM product_store WHERE id=".$id; 
        }
        
      // echo $query ;
      
       $result = $connect->query($query);
       
        
        $this->close_connection($connect);
        return $result;
    }
      public function all_promotions($id=null)
    {
        $connect = $this->get_connection();
        if(is_null($id))
        {
        $query = "SELECT * FROM promotions"; 
        }  else {
            $query = "SELECT * FROM promotions WHERE id=".$id; 
        }
        
      // echo $query ;
      
       $result = $connect->query($query);
       
        
        $this->close_connection($connect);
        return $result;
    }
      public function all_events($id=null)
    {
        $connect = $this->get_connection();
        if(is_null($id))
        {
        $query = "SELECT * FROM news_events"; 
        }  else {
            $query = "SELECT * FROM news_events WHERE id=".$id; 
        }
        
      // echo $query ;
      
       $result = $connect->query($query);
       
        
        $this->close_connection($connect);
        return $result;
    }
    public function goldrate_settings($amount,$update)
    {
         $connect = $this->get_connection();
         if($update<0)
         {
             $query = "INSERT INTO goldrate(price)VALUES(".$amount.")";
             $connect->query($query);
             
         }
 else {
     $query = "UPDATE goldrate SET price=".$amount.",updated=NOW() WHERE id=".$update;
             $connect->query($query);
 }
         $this->close_connection($connect);
         //echo $query;
         $this->redirect_home(4);
    }
    public function goldrate_gettings()
    {
        $connect = $this->get_connection();
        $query = "SELECT * FROM goldrate ";
        $result = $connect->query($query);
        $this->close_connection($connect);
        return $result;
    }
    
    public function redirect_home($case)
    {
        switch($case){
            case 1:header('location:?lead=list_products');break;
            case 2:header('location:?lead=list_promotions');break;
            case 3:header('location:?lead=list_events');break;
            case 4:header('location:index.php');break;
            case 5:break;
            default :break;
        }
    }
    
    public function login($username,$password) {
        
         $connect = $this->get_connection();
         $query = "SELECT * FROM login WHERE username='".$username."' AND password='".$password."'"; 
         $result = $connect->query($query);
         $row = mysqli_fetch_object($result);
         $_SESSION['account'] = $row->id;
        
        $this->close_connection($connect);
        $this->redirect_home(4);
        
    }
    public function logout()
    {
        $_SESSION['account'] = NULL;
        $this->redirect_home(4);
    }
    
}