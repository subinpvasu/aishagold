<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * A mangosoft.in production
 */
?>
 <div class="col-sm-2 sidenav text-left sub-div">
      <p class="menu-item-gap"><a href="#">Banner</a></p>
      <p class="menu-item-gap"><a href="#">Background</a></p>
      <p class="menu-item-gap"><a href="?lead=list_promotions">Promotions</a></p>
      <p class="menu-item-gap"><a href="?lead=list_events">News &amp; Events</a></p>
      <p class="menu-item-gap"><a href="?lead=list_products">Products</a></p>
      <p class="menu-item-gap"><a href="#">Site Settings</a></p>
      <p class="menu-item-gap"><a href="?lead=change_password">Change Password</a></p>
</div>
